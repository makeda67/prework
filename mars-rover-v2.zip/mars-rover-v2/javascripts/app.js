var orden = null;

function sub() {
  orden = document.getElementById("mov").value;
  commands(orden);
}

function commands(orden){
  var marsRover = new Object();
  marsRover.direccion = "N";
  marsRover.posicionX = 0;
  marsRover.posicionY = 0;
  marsRover.travelLog = [];
  
  var x=0;
    while (x <= orden.length) {
      console.log("posición del string" + x);
      switch (orden.charAt(x)) {
        case "r":
          console.log("Leyendo comando: " + orden.charAt(x));
          turnRight(marsRover);
        break;
        case "l":
            console.log("Leyendo comando: " + orden.charAt(x));
          turnLeft(marsRover);
        break;
        case "f":
            console.log("Leyendo comando: " + orden.charAt(x));
          moveForward(marsRover);
        break;
        
      }
    x++;
    }
    //función giro left
  function turnLeft(marsRover){
    console.log("turnLeft was called!");
    console.log("Dirección original "+marsRover.direccion);
    switch (marsRover.direccion) {
      case "N":
        marsRover.direccion = "W";
        break;
      case "W":
        marsRover.direccion = "S";
        break;
        case "S":
          marsRover.direccion = "E";
        break;
      case "E":
          marsRover.direccion = "N";
        break;
        
    }console.log("Dirección nueva "+ marsRover.direccion);
  }
  //función giro right
  function turnRight(marsRover){
    console.log("turnRight was called!");
    console.log("Dirección original: "+marsRover.direccion);
    switch (marsRover.direccion) {
    case "N":
        marsRover.direccion = "E";
        break;
      case "E":
        marsRover.direccion = "S";
        break;
        case "S":
          marsRover.direccion = "W";
        break;
      case "W":
          marsRover.direccion = "N";
        break;
    }console.log("Dirección nueva "+ marsRover.direccion);
  }
  //función movimiento
  function moveForward(marsRover){
    console.log("moveForward was called");
    console.log("Dirección original "+marsRover.direccion);
    marsRover.travelLog.push("(" + marsRover.posicionX + " , " + marsRover.posicionY + ")");
    switch (marsRover.direccion) {
      case "N":
        marsRover.posicionY = marsRover.posicionY-1;
        break;
      case "S":
        marsRover.posicionY = marsRover.posicionY+1;
        break; 
      case "W":
        marsRover.posicionX = marsRover.posicionX-1;
      break;
      case "E":
        marsRover.posicionX = marsRover.posicionX+1;
      break;
    }console.log("Dirección nueva "+ marsRover.direccion);
  }
  // Lectura del travelLog
  var i=0;
  while (i < marsRover.travelLog.length) {
    console.log(`Estas son las posiciones por las que ha pasado el Rover: Posición ${i} - ${marsRover.travelLog[i]}`);
   i++; 
   }
  }
  
